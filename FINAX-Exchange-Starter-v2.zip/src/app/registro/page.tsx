 "use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function RegisterPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signUp({
        email, password,
        options: { data: { full_name: name } }
      });
      if (error) throw error;
      setMessage("Solicitud recibida. Revisa tu correo para confirmar la dirección. Tu cuenta quedará pendiente de aprobación administrativa.");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "No se pudo completar el registro.");
    } finally { setBusy(false); }
  }

  return <main className="auth-page"><div className="auth-card">
    <Link href="/" className="brand"><span className="brand-mark">F</span><span>FINAX<small>EXCHANGE</small></span></Link>
    <div className="eyebrow auth-eyebrow">ÚNETE A FINAX</div><h1>Crear cuenta</h1>
    <p className="auth-copy">Registra tus datos para solicitar acceso a FINAX Exchange.</p>
    <form onSubmit={submit} className="auth-form">
      <label>Nombre completo<input required value={name} onChange={e=>setName(e.target.value)} autoComplete="name" /></label>
      <label>Correo electrónico<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" /></label>
      <label>Contraseña<input required type="password" minLength={10} value={password} onChange={e=>setPassword(e.target.value)} autoComplete="new-password" /><small>Mínimo 10 caracteres.</small></label>
      <button className="button button-full" disabled={busy}>{busy ? "Enviando..." : "Solicitar registro"}</button>
    </form>
    {message && <p className="notice" role="status">{message}</p>}
    <p className="auth-foot">¿Ya tienes cuenta? <Link href="/login">Iniciar sesión</Link></p>
    <p className="auth-disclaimer">El registro no garantiza aprobación ni habilita operaciones financieras.</p>
  </div></main>;
}