 "use client";

import { useMemo, useState } from "react";
import { ArrowDownUp, ArrowRight, BadgeCheck, Banknote, Bitcoin, ChevronDown, CircleHelp, Clock3, Coins, Globe2, LockKeyhole, Menu, ShieldCheck, Wallet, X } from "lucide-react";

type Currency = "VES" | "USD";
const DEMO_BUY_RATE = 250;
const DEMO_FEE_PERCENT = 1;

export default function Home() {
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [currency, setCurrency] = useState<Currency>("VES");
  const [amount, setAmount] = useState("100");
  const [menuOpen, setMenuOpen] = useState(false);
  const [notice, setNotice] = useState("");

  const calc = useMemo(() => {
    const qty = Math.max(0, Number(amount) || 0);
    const subtotal = currency === "USD" ? qty : qty * DEMO_BUY_RATE;
    const fee = subtotal * DEMO_FEE_PERCENT / 100;
    return { qty, subtotal, fee, total: side === "buy" ? subtotal + fee : Math.max(0, subtotal - fee) };
  }, [amount, currency, side]);

  const requestDemo = () => setNotice("Esta es una demostración. No se ejecutó ninguna operación ni se movió dinero real.");

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#"><span className="brand-mark">F</span><span>FINAX<small>EXCHANGE</small></span></a>
        <nav className={menuOpen ? "nav nav-open" : "nav"}>
          <a href="#como-funciona" onClick={() => setMenuOpen(false)}>Cómo funciona</a>
          <a href="#exchange" onClick={() => setMenuOpen(false)}>Exchange</a>
          <a href="#seguridad" onClick={() => setMenuOpen(false)}>Seguridad</a>
        </nav>
        <div className="top-actions">
          <a className="login-link" href="mailto:soporte@finax.example?subject=Acceso%20FINAX">Iniciar sesión</a>
          <a className="button button-small" href="mailto:soporte@finax.example?subject=Registro%20FINAX">Crear cuenta <ArrowRight size={15}/></a>
        </div>
        <button className="menu-button" aria-label="Abrir menú" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X/> : <Menu/>}</button>
      </header>

      <section className="hero shell">
        <div className="hero-copy">
          <div className="eyebrow"><span className="live-dot"/> FINANZAS DIGITALES, MÁS SIMPLES</div>
          <h1>Tu dinero.<br/><em>Tus decisiones.</em></h1>
          <p className="hero-text">Una nueva forma de gestionar dólares, bolívares y USDT desde una experiencia diseñada para darte claridad y control.</p>
          <div className="hero-buttons"><a className="button" href="#exchange">Explorar Exchange <ArrowRight size={17}/></a><a className="text-link" href="#como-funciona">Conoce FINAX <ArrowRight size={15}/></a></div>
          <div className="trust-line"><ShieldCheck size={17}/> Experiencia transparente <span/> <LockKeyhole size={16}/> Enfoque en seguridad</div>
        </div>
        <div className="hero-art" aria-label="Tarjeta ilustrativa FINAX">
          <div className="glow"/>
          <div className="floating-tag tag-one"><span className="tag-icon"><Coins size={17}/></span><span><b>USDT</b><small>TRON · TRC20</small></span><BadgeCheck className="gold-icon" size={17}/></div>
          <div className="wallet-card">
            <div className="wallet-card-top"><span>FINAX <small>WALLET</small></span><span className="chip"/></div>
            <div className="wallet-label">VISTA GENERAL</div>
            <div className="wallet-amount">Tu próxima<br/>experiencia financiera.</div>
            <div className="wallet-card-bottom"><span>USD · VES · USDT</span><span>•••• 2048</span></div>
          </div>
          <div className="floating-tag tag-two"><span className="round-icon"><ArrowDownUp size={16}/></span><span><b>Exchange</b><small>Compra y vende</small></span></div>
          <div className="hero-orbit orbit-a"/><div className="hero-orbit orbit-b"/>
        </div>
      </section>

      <section className="ticker"><div className="ticker-inner"><span><i/> USD</span><b>DÓLARES</b><span><i/> VES</span><b>BOLÍVARES</b><span><i/> USDT</span><b>TRON · TRC20</b><span className="ticker-note">Múltiples monedas. Una plataforma.</span></div></section>

      <section className="section shell" id="exchange">
        <div className="section-heading"><div><div className="eyebrow">FINAX EXCHANGE</div><h2>El intercambio,<br/><em>más sencillo.</em></h2></div><p>Consulta una cotización ilustrativa y descubre cómo será la experiencia de compra y venta de USDT.</p></div>
        <div className="exchange-layout">
          <div className="exchange-info">
            <div className="feature"><span><ArrowDownUp/></span><div><b>Compra y vende</b><p>Operaciones claras entre USDT, dólares y bolívares.</p></div></div>
            <div className="feature"><span><Clock3/></span><div><b>Tasas administradas</b><p>Las tasas de compra y venta serán establecidas por FINAX.</p></div></div>
            <div className="feature"><span><ShieldCheck/></span><div><b>Comisiones transparentes</b><p>La comisión porcentual se mostrará antes de confirmar.</p></div></div>
            <div className="demo-note"><CircleHelp size={17}/> Simulador de demostración: no usa tasas de mercado ni ejecuta transacciones reales.</div>
          </div>
          <div className="exchange-card">
            <div className="card-heading"><div><span className="eyebrow">SIMULADOR</span><h3>Calcula tu operación</h3></div><span className="demo-badge">DEMO</span></div>
            <div className="tabs"><button className={side === "buy" ? "tab active" : "tab"} onClick={() => setSide("buy")}>Comprar USDT</button><button className={side === "sell" ? "tab active" : "tab"} onClick={() => setSide("sell")}>Vender USDT</button></div>
            <label className="field-label">Quiero {side === "buy" ? "comprar" : "vender"}</label>
            <div className="amount-field"><input aria-label="Cantidad de USDT" value={amount} onChange={e => setAmount(e.target.value.replace(",", "."))} inputMode="decimal"/><span className="currency-pill"><span className="usdt-symbol">₮</span> USDT</span></div>
            <label className="field-label">Moneda de cálculo</label>
            <div className="currency-switch"><button className={currency === "VES" ? "selected" : ""} onClick={() => setCurrency("VES")}>VES · Bolívares</button><button className={currency === "USD" ? "selected" : ""} onClick={() => setCurrency("USD")}>USD · Dólares</button></div>
            <div className="calc-box">
              <div className="calc-row"><span>Tasa ilustrativa</span><b>{currency === "VES" ? `${DEMO_BUY_RATE.toLocaleString("es-VE")} VES / USDT` : "1 USD / USDT"}</b></div>
              <div className="calc-row"><span>Subtotal estimado</span><b>{calc.subtotal.toLocaleString("es-VE", {maximumFractionDigits: 2})} {currency}</b></div>
              <div className="calc-row"><span>Comisión demo ({DEMO_FEE_PERCENT}%)</span><b>{calc.fee.toLocaleString("es-VE", {maximumFractionDigits: 2})} {currency}</b></div>
              <div className="calc-total"><span>{side === "buy" ? "Total estimado a pagar" : "Estimado a recibir"}</span><strong>{calc.total.toLocaleString("es-VE", {maximumFractionDigits: 2})} {currency}</strong></div>
            </div>
            <button className="button button-full" onClick={requestDemo}>Continuar <ArrowRight size={17}/></button>
            {notice && <p className="notice" role="status">{notice}</p>}
            <p className="fine-print">Importes ilustrativos. Las tasas y comisiones definitivas serán configuradas por el administrador.</p>
          </div>
        </div>
      </section>

      <section className="dark-band" id="como-funciona"><div className="shell"><div className="eyebrow">UNA EXPERIENCIA INTEGRADA</div><h2>Todo conectado.<br/><em>Todo más claro.</em></h2><div className="steps"><div><span>01</span><Banknote/><h3>Deposita</h3><p>Prepara depósitos bancarios o en USDT, sujetos a verificación.</p></div><div><span>02</span><ArrowDownUp/><h3>Intercambia</h3><p>Consulta tasas, comisiones y confirma cada operación.</p></div><div><span>03</span><Wallet/><h3>Administra</h3><p>Visualiza tus billeteras y el historial de movimientos.</p></div></div></div></section>

      <section className="section shell security-section" id="seguridad"><div className="security-icon"><ShieldCheck size={30}/></div><div><div className="eyebrow">CONFIANZA Y CONTROL</div><h2>La claridad también<br/><em>es seguridad.</em></h2><p>FINAX está diseñado con aprobación de usuarios, revisión de operaciones y registro de actividad como principios fundamentales. Las funciones financieras reales se habilitarán después de integrar proveedores y controles adecuados.</p></div></section>

      <footer className="footer"><div className="footer-top"><a className="brand" href="#"><span className="brand-mark">F</span><span>FINAX<small>EXCHANGE</small></span></a><span>USD · VES · USDT</span></div><div className="footer-bottom"><span>© {new Date().getFullYear()} FINAX. Todos los derechos reservados.</span><span>Versión inicial de demostración</span></div></footer>
    </main>
  );
}