import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { ShieldAlert } from "lucide-react";

export default async function AdminPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("role,status").eq("id", user.id).maybeSingle();
  if (profile?.role !== "admin") redirect("/dashboard");

  return <main className="portal-page"><header className="portal-header"><Link href="/" className="brand"><span className="brand-mark">F</span><span>FINAX<small>ADMIN</small></span></Link><Link href="/dashboard" className="logout">Volver al portal</Link></header><section className="portal-content"><div className="eyebrow">CONTROL ADMINISTRATIVO</div><h1>Panel de administración</h1><div className="status-card"><ShieldAlert size={24}/><div><b>Acceso administrativo autorizado</b><p>Este es el esqueleto inicial. No se han habilitado acciones de aprobación, ajustes de tasas ni movimientos de saldo.</p></div></div><div className="portal-grid"><div className="portal-tile"><h3>Usuarios</h3><p>La gestión de solicitudes y aprobaciones requiere acciones de servidor auditadas.</p></div><div className="portal-tile"><h3>Tasas y comisiones</h3><p>Se implementarán controles para publicar tasas manuales y porcentajes por operación.</p></div><div className="portal-tile"><h3>Depósitos y retiros</h3><p>La revisión manual y conciliación se integrarán antes de producción.</p></div></div></section></main>;
}