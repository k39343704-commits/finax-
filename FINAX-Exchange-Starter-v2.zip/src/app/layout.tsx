import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FINAX Exchange | Finanzas digitales",
  description: "Compra y vende USDT con una experiencia clara y segura.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body>{children}</body></html>;
}