import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { LogOut, ShieldCheck, Wallet } from "lucide-react";

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("full_name,status,role").eq("id", user.id).maybeSingle();
  async function signOut() { "use server"; const client = await createClient(); await client.auth.signOut(); redirect("/"); }

  return <main className="portal-page"><header className="portal-header"><Link href="/" className="brand"><span className="brand-mark">F</span><span>FINAX<small>EXCHANGE</small></span></Link><form action={signOut}><button className="logout"><LogOut size={16}/> Salir</button></form></header>
    <section className="portal-content"><div className="eyebrow">ESPACIO DEL CLIENTE</div><h1>Hola, {profile?.full_name || user.email}</h1>
      <div className="status-card"><ShieldCheck size={24}/><div><b>Estado de tu cuenta: {profile?.status || "pendiente"}</b><p>{profile?.status === "approved" ? "Tu cuenta está aprobada. Las funciones de operación se habilitarán cuando FINAX complete sus integraciones." : "Tu solicitud está pendiente de revisión administrativa. No podrás operar hasta recibir aprobación."}</p></div></div>
      <div className="portal-grid"><div className="portal-tile"><Wallet/><h3>Billeteras</h3><p>La vista de saldos estará disponible al conectar el libro contable y habilitar las operaciones.</p><span>Próximamente</span></div><div className="portal-tile"><ShieldCheck/><h3>Seguridad</h3><p>Tu acceso está gestionado mediante Supabase Auth. Se recomienda activar MFA antes del lanzamiento.</p><span>Configuración inicial</span></div></div>
      <p className="portal-warning">Esta versión no guarda ni transfiere fondos. No deposites dinero ni envíes criptomonedas.</p>
    </section></main>;
}