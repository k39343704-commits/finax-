 "use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const params = useSearchParams();
  const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [message,setMessage]=useState(""); const [busy,setBusy]=useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      const supabase=createClient();
      const {error}=await supabase.auth.signInWithPassword({email,password});
      if(error) throw error;
      window.location.assign(params.get("next") || "/dashboard");
    } catch(err) { setMessage(err instanceof Error ? err.message : "No se pudo iniciar sesión."); }
    finally { setBusy(false); }
  }
  return <main className="auth-page"><div className="auth-card">
    <Link href="/" className="brand"><span className="brand-mark">F</span><span>FINAX<small>EXCHANGE</small></span></Link>
    <div className="eyebrow auth-eyebrow">BIENVENIDO DE NUEVO</div><h1>Iniciar sesión</h1>
    <p className="auth-copy">Accede a tu espacio FINAX.</p>
    <form onSubmit={submit} className="auth-form">
      <label>Correo electrónico<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email"/></label>
      <label>Contraseña<input required type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password"/></label>
      <button className="button button-full" disabled={busy}>{busy ? "Ingresando..." : "Entrar a FINAX"}</button>
    </form>
    {message && <p className="notice" role="alert">{message}</p>}
    <p className="auth-foot">¿Aún no tienes cuenta? <Link href="/registro">Solicitar registro</Link></p>
  </div></main>;
}