# FINAX Exchange — starter web project

Starter de Next.js para la web pública de FINAX, con identidad negro/dorado y simulador visual de compra/venta USDT.

## Requisitos
- Node.js 20 LTS o superior
- npm
- Cuenta Supabase (solo cuando se conecte autenticación/base de datos)

## Ejecutar localmente
```bash
npm install
npm run dev
```
Abre http://localhost:3000.

## Compilar
```bash
npm run build
npm start
```

## Publicar en Vercel
1. Sube este proyecto a un repositorio privado de GitHub.
2. En Vercel, importa el repositorio.
3. Framework: Next.js; Build command: `npm run build`.
4. Añade las variables de entorno de `.env.example` cuando Supabase esté configurado.
5. Publica primero como entorno de prueba y valida el sitio.

## Supabase
El archivo `supabase/schema.sql` contiene un esquema inicial para perfiles, wallets, tasas, comisiones, transacciones y auditoría. Revísalo y aplícalo en un proyecto Supabase de desarrollo. Las escrituras financieras NO están implementadas: deben ejecutarse en backend confiable con autorización por rol, transacciones SQL atómicas, bloqueo de saldos, idempotencia, límites y auditoría.

## Configuración comercial actual
- Nombre: FINAX Exchange
- Monedas: VES, USD, USDT
- Red prevista: TRON / TRC20
- Tasas: manuales, configuradas por administración
- Comisiones: porcentuales configurables
- Alta de usuarios: pendiente de aprobación administrativa

## Importante: estado del proyecto
Esta entrega es un **starter de interfaz y estructura**, no una plataforma financiera operativa. El simulador utiliza números ficticios (250 VES/USDT, 1% de comisión) únicamente para demostrar el diseño. No consulta BCV, no autentica usuarios, no acepta depósitos, no transmite USDT y no mueve fondos.

Antes de manejar dinero real se requiere implementar y auditar:
- autenticación, MFA y roles;
- KYC/AML, sanciones, límites y prevención de fraude;
- motor de cotización y libro contable de doble entrada;
- custodia segura y proveedor TRON con confirmaciones e idempotencia;
- conciliación bancaria, gestión de liquidez y reversos;
- controles legales/regulatorios aplicables a los países donde opere FINAX;
- monitoreo, copias de seguridad, gestión de secretos y pruebas de seguridad.

No pongas claves privadas, service-role keys ni credenciales en el navegador o en Git.


## Segunda etapa: autenticación y portal
Se añadieron:
- `/registro`: registro con Supabase Auth; perfil y wallets iniciales se crean pendientes mediante trigger SQL.
- `/login`: inicio de sesión.
- `/dashboard`: portal cliente protegido.
- `/admin`: esqueleto protegido que solo permite entrar a perfiles con `role = 'admin'`.
- `src/middleware.ts`: protección de rutas privadas cuando las variables Supabase están configuradas.

### Configurar dominio finaxgroup.com
El dominio no se configura automáticamente desde el proyecto. En el proveedor donde esté registrado:
1. Comprueba que `finaxgroup.com` está registrado y bajo tu control.
2. Añádelo como dominio personalizado en Vercel.
3. Configura los registros DNS exactamente como indique Vercel (normalmente A/ALIAS para raíz y CNAME para `www`; usa los valores que muestre tu panel).
4. Añade `finaxgroup.com` y `www.finaxgroup.com` en Authentication → URL Configuration de Supabase, junto con las URLs de redirección necesarias.
5. Configura en Vercel `NEXT_PUBLIC_SUPABASE_URL` y `NEXT_PUBLIC_SUPABASE_ANON_KEY`.

No he comprobado disponibilidad ni titularidad de `finaxgroup.com`.

### Activar el primer administrador
Después de crear tu usuario de prueba y aplicar el esquema, asigna el rol admin desde el SQL Editor de Supabase solo a una cuenta que controles:
```sql
update public.profiles
set role = 'admin', status = 'approved', approved_at = now()
where email = 'TU_CORREO_VERIFICADO';
```
No compartas claves privadas ni `service_role` key. La cuenta admin debe protegerse con MFA.

### Antes de producción
La autenticación y las páginas protegidas son un punto de partida, no una certificación de seguridad. Las políticas de escritura financiera, aprobación administrativa, ledger de doble entrada, conciliación, límites, monitoreo y controles regulatorios aún deben desarrollarse y auditarse. No procesar dinero real en esta versión.
