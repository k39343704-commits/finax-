-- FINAX initial schema. Review with qualified security/compliance and engineering teams before production.
create extension if not exists pgcrypto;

create type public.user_role as enum ('customer','admin');
create type public.account_status as enum ('pending','approved','rejected','suspended');
create type public.asset_code as enum ('VES','USD','USDT');
create type public.transaction_status as enum ('pending','under_review','approved','rejected','completed','cancelled');
create type public.transaction_kind as enum ('deposit','withdrawal','buy_usdt','sell_usdt','adjustment');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  role public.user_role not null default 'customer',
  status public.account_status not null default 'pending',
  created_at timestamptz not null default now(),
  approved_at timestamptz
);

create table public.wallets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  asset public.asset_code not null,
  balance numeric(24,8) not null default 0 check (balance >= 0),
  created_at timestamptz not null default now(),
  unique(user_id, asset)
);

create table public.exchange_rates (
  id uuid primary key default gen_random_uuid(),
  base_asset public.asset_code not null,
  quote_asset public.asset_code not null,
  buy_rate numeric(24,8) not null check (buy_rate > 0),
  sell_rate numeric(24,8) not null check (sell_rate > 0),
  active boolean not null default false,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  check (base_asset <> quote_asset)
);

create unique index one_active_rate_per_pair on public.exchange_rates(base_asset, quote_asset) where active = true;

create table public.fee_settings (
  id uuid primary key default gen_random_uuid(),
  operation text not null check (operation in ('buy_usdt','sell_usdt','deposit','withdrawal')),
  percentage numeric(8,5) not null default 0 check (percentage >= 0 and percentage <= 100),
  active boolean not null default true,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

create table public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  kind public.transaction_kind not null,
  status public.transaction_status not null default 'pending',
  from_asset public.asset_code,
  to_asset public.asset_code,
  from_amount numeric(24,8) check (from_amount is null or from_amount > 0),
  to_amount numeric(24,8) check (to_amount is null or to_amount >= 0),
  applied_rate numeric(24,8),
  fee_percent numeric(8,5) not null default 0,
  fee_amount numeric(24,8) not null default 0,
  reference text unique,
  notes text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id)
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.exchange_rates enable row level security;
alter table public.fee_settings enable row level security;
alter table public.transactions enable row level security;
alter table public.audit_logs enable row level security;

-- Minimal read policies only. Financial writes must go through trusted server-side
-- functions with authorization, idempotency, balance locking and audit logging.
create policy "users read own profile" on public.profiles for select using (auth.uid() = id);
create policy "users read own wallets" on public.wallets for select using (auth.uid() = user_id);
create policy "users read own transactions" on public.transactions for select using (auth.uid() = user_id);
create policy "authenticated users read active rates" on public.exchange_rates for select to authenticated using (active = true);


-- Create a pending customer profile after Supabase Auth signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, email, status, role)
  values (
    new.id,
    new.raw_user_meta_data ->> 'full_name',
    new.email,
    'pending',
    'customer'
  );
  insert into public.wallets (user_id, asset)
  values (new.id, 'VES'), (new.id, 'USD'), (new.id, 'USDT');
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Admin role must be assigned manually by a trusted project owner in Supabase SQL.
-- Never expose service-role credentials in the frontend.
